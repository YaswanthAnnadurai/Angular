import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'countrySort',
})
export class CountrySortPipe implements PipeTransform {
  transform(countries: string[], sortOrder: 'asc' | 'desc'): string[] {
    if (!countries || countries.length <= 1) {
      return countries;
    }

    return countries.sort((a, b) => {
      if (sortOrder === 'asc') {
        return a.localeCompare(b);
      } else {
        return b.localeCompare(a);
      }
    });
  }
}