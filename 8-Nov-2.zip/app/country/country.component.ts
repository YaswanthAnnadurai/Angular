import { Component } from '@angular/core';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
  export class CountryComponent {
    countries: string[] = ['USA', 'Canada', 'India', 'Australia'];
    newCountry: string = '';
    sortOrder: 'asc' | 'desc' = 'asc';
  
    addCountry() {
      if (this.newCountry.trim() !== '') {
        this.countries.push(this.newCountry);
        this.newCountry = '';
      }
    }
  }
