import { Directive ,ElementRef,Renderer2} from '@angular/core';

@Directive({
  selector: '[appReadonly]'
})
export class ReadonlyDirective {

  constructor(private el: ElementRef, private renderer: Renderer2) {
    this.renderer.setProperty(this.el.nativeElement, 'readOnly',true);
  }


}
